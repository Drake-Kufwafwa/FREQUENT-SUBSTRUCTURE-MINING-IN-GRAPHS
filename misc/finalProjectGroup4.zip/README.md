# FREQUENT-SUBSTRUCTURE-MINING-IN-GRAPHS

For report and evaluations see freq_subgraph_mining.ipynb or freq_subgraph_mining.html. 
